const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = 320;
canvas.height = 480;

const gameOverScreen = document.getElementById("gameOverScreen");
const startScreen = document.getElementById("startScreen");
const finalScoreDisplay = document.getElementById("finalScore");

let birdImg = new Image();
birdImg.src = "https://i.postimg.cc/Cz7w5WBf/flappy-bird.png";

let pipeImg = new Image();
pipeImg.src = "https://i.postimg.cc/68hcDfPK/pipe.png";

let bird, pipes, score, gameOver, pipeSpeed, gameStarted = false;
let speedIncreaseInterval;

function initGame() {
    bird = { x: 50, y: 150, width: 34, height: 24, velocity: 0, gravity: 0.4, lift: -8 };
    pipes = [];
    score = 0;
    gameOver = false;
    gameStarted = false;
    pipeSpeed = 1.5;
}

function prepareGame() {
    startScreen.style.display = "none";
    canvas.style.display = "block";
    initGame();
    document.addEventListener("keydown", startOnFirstClick, { once: true });
}

function startOnFirstClick() {
    gameStarted = true;
    speedIncreaseInterval = setInterval(() => {
        if (pipeSpeed < 3) pipeSpeed += 0.1;
    }, 5000);
    loop();
}

function restartGame() {
    gameOverScreen.style.display = "none";
    canvas.style.display = "block";
    clearInterval(speedIncreaseInterval);
    initGame();
    document.addEventListener("keydown", startOnFirstClick, { once: true });
}

function drawBird() {
    ctx.drawImage(birdImg, bird.x, bird.y, bird.width, bird.height);
}

function drawPipes() {
    pipes.forEach(pipe => {
        ctx.drawImage(pipeImg, pipe.x, 0, pipe.width, pipe.top);
        ctx.save();
        ctx.translate(pipe.x + pipe.width / 2, pipe.bottom + (canvas.height - pipe.bottom) / 2);
        ctx.rotate(Math.PI);
        ctx.drawImage(pipeImg, -pipe.width / 2, -((canvas.height - pipe.bottom) / 2), pipe.width, canvas.height - pipe.bottom);
        ctx.restore();
    });
}

function update() {
    if (gameOver || !gameStarted) return;
    
    bird.velocity += bird.gravity;
    bird.y += bird.velocity;

    if (bird.y + bird.height >= canvas.height || bird.y <= 0) {
        endGame();
    }

    pipes.forEach(pipe => {
        pipe.x -= pipeSpeed;
        if (pipe.x + pipe.width < 0) {
            pipes.shift();
            score++;
        }
        if (
            bird.x < pipe.x + pipe.width && bird.x + bird.width > pipe.x && 
            (bird.y < pipe.top || bird.y + bird.height > pipe.bottom)
        ) {
            endGame();
        }
    });

    if (pipes.length === 0 || pipes[pipes.length - 1].x < canvas.width - 150) {
        let gap = 160; // Increased pipe gap for easier start
        let topHeight = Math.floor(Math.random() * (canvas.height - gap - 50)) + 50;
        pipes.push({ x: canvas.width, width: 40, top: topHeight, bottom: topHeight + gap });
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBird();
    drawPipes();
    ctx.fillStyle = "white";
    ctx.font = "16px 'Press Start 2P', cursive";
    ctx.fillText("Score: " + score, 10, 20);
}

function loop() {
    if (gameOver) return;
    update();
    draw();
    requestAnimationFrame(loop);
}

function endGame() {
    gameOver = true;
    clearInterval(speedIncreaseInterval);
    canvas.style.display = "none";
    gameOverScreen.style.display = "block";
    finalScoreDisplay.textContent = score;
}

document.addEventListener("keydown", () => { if (gameStarted && !gameOver) bird.velocity = bird.lift; });
